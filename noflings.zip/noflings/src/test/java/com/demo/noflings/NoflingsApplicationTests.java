package com.demo.noflings;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NoflingsApplicationTests {

	@Test
	void contextLoads() {
	}

}
