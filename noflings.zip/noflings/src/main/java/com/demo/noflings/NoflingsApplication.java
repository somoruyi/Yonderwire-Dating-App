package com.demo.noflings;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NoflingsApplication {

	public static void main(String[] args) {
		SpringApplication.run(NoflingsApplication.class, args);
	}

}
